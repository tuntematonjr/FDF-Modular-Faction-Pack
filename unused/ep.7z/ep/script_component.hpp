#define COMPONENT ep
#include "\x\kar_fdf\addons\main\script_mod.hpp"

//#define DEBUG_MODE_FULL
//#define DISABLE_COMPILE_CACHE

#include "\x\kar_fdf\addons\main\script_macros.hpp"